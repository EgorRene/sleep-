package com.example.sleepy

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        ctx.startForegroundService(Intent(ctx, AlarmService::class.java))
        val s = Store(ctx)
        if (s.alarmOn) AlarmScheduler.schedule(ctx, s.hour, s.minute) // повтор каждый день
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val s = Store(ctx)
        if (s.alarmOn) AlarmScheduler.schedule(ctx, s.hour, s.minute)
    }
}
