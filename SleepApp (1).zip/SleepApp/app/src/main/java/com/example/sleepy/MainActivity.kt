package com.example.sleepy

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App() } } }
    }
}

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
private val dateFmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Text("⏰") }, label = { Text("Будильник") })
            NavigationBarItem(tab == 1, { tab = 1 }, { Text("🌙") }, label = { Text("Сон") })
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            if (tab == 0) AlarmTab() else SleepTab()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmTab() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val store = remember { Store(ctx) }
    val state = rememberTimePickerState(store.hour, store.minute, is24Hour = true)
    var on by remember { mutableStateOf(store.alarmOn) }
    var info by remember { mutableStateOf("") }

    fun apply(enable: Boolean) {
        store.hour = state.hour; store.minute = state.minute; store.alarmOn = enable; on = enable
        if (enable) {
            AlarmScheduler.schedule(ctx, state.hour, state.minute)
            val mins = (AlarmScheduler.nextTrigger(state.hour, state.minute) - System.currentTimeMillis()) / 60000
            info = "Прозвонит через ${mins / 60} ч ${mins % 60} мин"
        } else { AlarmScheduler.cancel(ctx); info = "Будильник выключен" }
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TimePicker(state)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Включить будильник  "); Switch(on, { apply(it) })
        }
        if (on) Button({ apply(true) }) { Text("Обновить время") }
        Text(info)
        OutlinedButton({
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(AlarmService.ACTION_STOP))
        }) { Text("Остановить звонок") }
    }
}

@Composable
fun SleepTab() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val store = remember { Store(ctx) }
    var start by remember { mutableLongStateOf(store.sleepStart) }
    var sessions by remember { mutableStateOf(store.sessions().reversed()) }

    val wake = AlarmScheduler.nextTrigger(store.hour, store.minute)
    val bedtimes = listOf(6, 5, 4).map { c -> c to Date(wake - c * 90 * 60000L - 15 * 60000L) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Button({
                if (start == 0L) { start = System.currentTimeMillis(); store.sleepStart = start }
                else {
                    store.addSession(start, System.currentTimeMillis())
                    start = 0L; store.sleepStart = 0L
                    sessions = store.sessions().reversed()
                }
            }, Modifier.fillMaxWidth()) {
                Text(if (start == 0L) "🌙 Ложусь спать" else "☀️ Я проснулся")
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Когда лечь, чтобы встать в ${timeFmt.format(Date(wake))}", style = MaterialTheme.typography.titleSmall)
                    bedtimes.forEach { (c, d) ->
                        Text("${timeFmt.format(d)} — $c циклов (${c * 1.5} ч сна)")
                    }
                }
            }
        }
        item { Text("История сна", style = MaterialTheme.typography.titleMedium) }
        items(sessions) { (a, b) ->
            val m = (b - a) / 60000
            Text("${dateFmt.format(Date(a))} → ${timeFmt.format(Date(b))}   ${m / 60} ч ${m % 60} мин")
        }
        if (sessions.isNotEmpty()) item {
            val avg = sessions.map { (it.second - it.first) / 60000 }.average().toLong()
            Text("Среднее: ${avg / 60} ч ${avg % 60} мин", style = MaterialTheme.typography.titleSmall)
        }
    }
}
