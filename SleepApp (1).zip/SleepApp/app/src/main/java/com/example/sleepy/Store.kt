package com.example.sleepy

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("sleep", Context.MODE_PRIVATE)
    var hour: Int get() = p.getInt("h", 7); set(v) = p.edit().putInt("h", v).apply()
    var minute: Int get() = p.getInt("m", 0); set(v) = p.edit().putInt("m", v).apply()
    var alarmOn: Boolean get() = p.getBoolean("on", false); set(v) = p.edit().putBoolean("on", v).apply()
    var sleepStart: Long get() = p.getLong("start", 0L); set(v) = p.edit().putLong("start", v).apply()

    fun sessions(): List<Pair<Long, Long>> =
        (p.getString("s", "") ?: "").split(";").filter { it.isNotBlank() }.map {
            val (a, b) = it.split(","); a.toLong() to b.toLong()
        }

    fun addSession(start: Long, end: Long) {
        val all = (sessions() + (start to end)).takeLast(30)
        p.edit().putString("s", all.joinToString(";") { "${it.first},${it.second}" }).apply()
    }
}
